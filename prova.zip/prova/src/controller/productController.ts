import type { Product } from "../interfaces/types";
import produtoModels from "../models/produtoModels";
import type { Request,Response } from "express";

const getProdutctAll =  async (req:Request, res:Response) =>{
    const listProducts = await produtoModels.getProdutctAll()
    return res.status(200).json(listProducts)
}

const getByProdutctId =  async (req:Request, res:Response) =>{
    const id = Number(req.params.id)
    const product = await produtoModels.getByProdutctId(id)
    return res.status(200).json(product)
}

const createNewProduct=  async (req:Request, res:Response) =>{
   
    const newProduct =  await produtoModels.createNewProdutct(req.body)    
    return res.status(201).json(newProduct) 
}
const editProdutc =  async (req:Request, res:Response) =>{
    const id = Number(req.params.id)    
    const productEdit = await produtoModels.editProdutc(id,req.body)
    return res.status(200).json(productEdit)
}

const editProdutcPartial = async (req:Request, res:Response)=>{
    const id = Number(req.params.id)
    const updates: Partial<Product> = req.body
    const result = await produtoModels.editProdutcPartial(id,updates)
    return res.status(200).json(result)
}
const removeProduct =  async (req:Request, res:Response) =>{
    const product = await produtoModels.removeProduct(Number(req.params.id))
    return res.status(200).json(product)
}

export default {
    getProdutctAll,
    getByProdutctId,
    createNewProduct,
    editProdutc,
    editProdutcPartial,
    removeProduct
}

