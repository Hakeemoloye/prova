import express from 'express'
import productController from './controller/productController'

export const router =  express.Router()

router.get('/', productController.getProdutctAll)
router.get('/produto/:id', productController.getByProdutctId)
router.post('/produto', productController.createNewProduct)
router.patch('/produto/:id', productController.editProdutcPartial)
router.put('/produto/:id', productController.editProdutc)
router.delete('/produto/:id', productController.removeProduct)